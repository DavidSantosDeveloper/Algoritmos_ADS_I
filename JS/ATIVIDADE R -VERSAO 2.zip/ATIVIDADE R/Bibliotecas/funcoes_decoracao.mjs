//------->>>>>>>>>>>>> CABECALHO <<<<<<<<<<<<<<<<---------------
export function cabecalho(texto) {
    console.log(`>>>>>>>>>>>>>>>>>>> ${texto} <<<<<<<<<<<<<<<<<<<<<<`)
}

export function cabecalho_V2(texto) {
    console.log(`\n\n#################### ${texto} ##########################`)
}

export function destacar_resposta_cabecalho() {
    console.log("\n\n*****************************RESPOSTA***************************")

}
export function destacar_resposta_rodape() {
    console.log("\n\n********************************************************")
}